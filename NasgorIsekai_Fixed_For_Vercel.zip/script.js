
document.addEventListener("DOMContentLoaded", () => {
    console.log("Welcome to NasgorIsekai!");
});
